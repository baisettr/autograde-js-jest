update user set NAME = 'test1a' where ID = 1
AND NAME='test1';