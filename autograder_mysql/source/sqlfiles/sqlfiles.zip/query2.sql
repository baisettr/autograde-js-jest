insert into user(ID,NAME,AGE) values (1,'test1',23);
insert into user(ID,NAME,AGE) values (2,'test2',24);